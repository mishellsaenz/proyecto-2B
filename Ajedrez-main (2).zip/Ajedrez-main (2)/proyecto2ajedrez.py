# Función para validar el ingreso de piezas
def validar_ingreso_pieza(tablero):
    tipos_validos = ['torre', 'alfil', 'peón', 'caballo', 'reina', 'rey']
    colores_validos = ['blanco', 'negro']
    
    # Pedir tipo de pieza
    tipo_pieza = input("Ingrese el tipo de pieza (torre, alfil, peón, caballo, reina, rey): ").lower()
    # Validar tipo de pieza
    while tipo_pieza not in tipos_validos:
        print("Tipo de pieza no válido. Por favor, ingrese un tipo de pieza válido.")
        tipo_pieza = input("Ingrese el tipo de pieza (torre, alfil, peón, caballo, reina, rey): ").lower()
    
    # Pedir color
    color = input("Ingrese el color de la pieza (blanco o negro): ").lower()
    # Validar color
    while color not in colores_validos:
        print("Color no válido. Por favor, ingrese blanco o negro.")
        color = input("Ingrese el color de la pieza (blanco o negro): ").lower()
    
    # Pedir posición
    fila_letra = input("Ingrese la fila de la pieza (A-H): ").upper()
    columna_numero = int(input("Ingrese la columna de la pieza (1-8): ")) - 1
    
    # Validar posición
    while fila_letra not in 'ABCDEFGH' or columna_numero not in range(8):
        print("Posición no válida. Por favor, ingrese una fila entre A-H y una columna entre 1-8.")
        fila_letra = input("Ingrese la fila de la pieza (A-H): ").upper()
        columna_numero = int(input("Ingrese la columna de la pieza (1-8): ")) - 1
    
    # Verificar si la casilla está ocupada
    if tablero[ord(fila_letra) - 65][columna_numero] != "v":
        print("La casilla seleccionada ya está ocupada.")
        return None, None, None, None
    
    return tipo_pieza, color, fila_letra, columna_numero

# Función para imprimir el tablero de ajedrez
def imprimir_tablero(tablero):
    print("  1 2 3 4 5 6 7 8")
    for i in range(8):
        print(chr(65 + i), end=' ')
        for j in range(8):
            print(tablero[i][j], end=' ')
        print()

# Función para obtener movimientos válidos hacia arriba
def movimientos_arriba(tablero, fila, columna):
    movimientos = []
    for i in range(fila - 1, -1, -1):
        if tablero[i][columna] == "v":
            movimientos.append((i, columna))
        else:
            break
    return movimientos

# Función para obtener movimientos válidos hacia abajo
def movimientos_abajo(tablero, fila, columna):
    movimientos = []
    for i in range(fila + 1, 8):
        if tablero[i][columna] == "v":
            movimientos.append((i, columna))
        else:
            break
    return movimientos

# Función para obtener movimientos válidos hacia la izquierda
def movimientos_izquierda(tablero, fila, columna):
    movimientos = []
    for j in range(columna - 1, -1, -1):
        if tablero[fila][j] == "v":
            movimientos.append((fila, j))
        else:
            break
    return movimientos

# Función para obtener movimientos válidos hacia la derecha
def movimientos_derecha(tablero, fila, columna):
    movimientos = []
    for j in range(columna + 1, 8):
        if tablero[fila][j] == "v":
            movimientos.append((fila, j))
        else:
            break
    return movimientos

# Función para listar movimientos válidos de una pieza
def listar_movimientos_validos(tablero, fila, columna):
    movimientos_validos = []
    movimientos_validos.extend(movimientos_arriba(tablero, fila, columna))
    movimientos_validos.extend(movimientos_abajo(tablero, fila, columna))
    movimientos_validos.extend(movimientos_izquierda(tablero, fila, columna))
    movimientos_validos.extend(movimientos_derecha(tablero, fila, columna))
    return movimientos_validos

# Crear tablero de ajedrez inicial
tablero = [["v" for _ in range(8)] for _ in range(8)]

# Repetir 4 veces la impresión del tablero
for _ in range(4):
    imprimir_tablero(tablero)
    tipo_pieza, color, fila_letra, columna_numero = validar_ingreso_pieza(tablero)
    if tipo_pieza:
        tablero[ord(fila_letra) - 65][columna_numero] = tipo_pieza[0] + color[0]  # Representar la pieza en el tablero
        imprimir_tablero(tablero)
        fila = ord(fila_letra) - 65
        columna = columna_numero
        movimientos_validos = listar_movimientos_validos(tablero, fila, columna)
        print("Movimientos válidos:")
        for mov in movimientos_validos:
            print(f"{chr(65 + mov[0])}{mov[1] + 1}")
